import { mount } from "@vue/test-utils";
import { it, expect } from "vitest";

it("Test to make sure it runs properly", () => {
  expect(true).toBeTruthy;
});
