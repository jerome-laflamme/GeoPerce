import { mount } from "@vue/test-utils";
import AboutUs from "../../src/views/AboutUs.vue";
import { it, expect } from "vitest";

it("Return text from info-wrapper ")